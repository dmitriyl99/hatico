<template>
<header class="p-3 bg-dark text-white shadow">
    <div class="container">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
          <svg class="bi me-2" width="40" height="32" role="img" aria-label="Bootstrap"><use xlink:href="#bootstrap"></use></svg>
          <h2 class="text-warning">Hati.co</h2>
        </a>
      </div>
    </div>
  </header>
</template>

<script>
export default {
    name: 'Header'
}
</script>