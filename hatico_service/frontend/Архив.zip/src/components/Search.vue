<template>
  <div class="container" id="search">
    <div class="w-100 shadow p-3 rounded bg-body">
      <h3 class="text-center">Поиск</h3>
      <div class="row mt-3">
        <div class="col-sm-12 col-md-4">
          <p class="mb-3 fw-bold fs-4 text-center">Окрас</p>
          <div class="d-flex justify-content-center">
            <div class="form-check">
              <input
                class="form-check-input"
                type="radio"
                v-model="color"
                value="light"
                name="colorRadio"
                id="colorRadio1"
              />
              <label class="form-check-label" for="colorRadio1"> Белый </label>
            </div>
            <div class="form-check ms-3">
              <input
                class="form-check-input"
                type="radio"
                value="dark"
                v-model="color"
                name="colorRadio"
                id="colorRadio2"
                checked
              />
              <label class="form-check-label" for="colorRadio"> Тёмный </label>
            </div>
            <div class="form-check ms-3">
              <input
                class="form-check-input"
                type="radio"
                v-model="color"
                value="multicolor"
                name="colorRadio"
                id="colorRadio3"
                checked
              />
              <label class="form-check-label" for="colorRadio3">
                Разноцветный
              </label>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-4">
          <p class="mb-3 fw-bold fs-4 text-center">Длина хвоста</p>
          <div class="d-flex justify-content-center">
            <div class="form-check">
              <input
                class="form-check-input"
                type="radio"
                v-model="tail"
                value="short"
                name="tailRadio"
                id="tailRadio1"
              />
              <label class="form-check-label" for="tailRadio1">
                Короткий
              </label>
            </div>
            <div class="form-check ms-3">
              <input
                class="form-check-input"
                type="radio"
                v-model="tail"
                value="long"
                name="tailRadio"
                id="tailRadio2"
                checked
              />
              <label class="form-check-label" for="tailRadio2"> Длинный </label>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-4">
          <p class="mb-3 fw-bold fs-4 text-center">Порода</p>
          <select name="breed" id="breedSelect" class="form-select" v-model="breed">
            <option selected disabled>Выберите породу</option>
            <option
              v-for="breed in breeds"
              :key="breed.name"
              :value="breed.name"
            >
              {{ breed.display }}
            </option>
          </select>
        </div>
      </div>
      <div class="d-flex justify-content-end mt-4">
        <button type="button" class="btn btn-primary">Искать</button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: "Search",
  data() {
    return {
      breeds: [
        {
          name: "samoyed",
          display: "Самоед",
        },
        {
          name: "basset",
          display: "Такса",
        },
      ],
      color: '',
      tail: '',
      breed: ''
    };
  },
  methods: {
    onSubmit() {
      if (this.color != '' && this.tail != '' && this.breed != '') {
        alert('Заполните все данные')
      }
    }
  }
};
</script>